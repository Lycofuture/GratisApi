<?php
header('Content-Type:application/json');
require '../../curl.php';
require '../../need.php';
require ("../function.php"); // 引入函数文件
addAccess();//调用统计函数
addApiAccess(134); // 调用统计函数
$QQ = $_REQUEST['QQ'];
$url = $_REQUEST['url'];
$rand = $_REQUEST['format'];
$Type = $_REQUEST['type'];
if(!is_num($QQ) && empty($url)){
    Switch($Type){
        case 'text':
        send('请输入QQ或者链接','text');
        break;
        default:
        header('content-type:image/jpeg');
        $image = new imagick('./tumeile.jpg');
        echo $image;
        exit();
        break;
    }
}
if(empty($url)){
    $url = 'http://q2.qlogo.cn/headimg_dl?dst_uin='.$QQ.'&spec=5';
}
if(!is_num($QQ)){
    $url = $url;
}
$read = read_all('./head');//原图
if($Type == 1){
    print_r($read);exit;
}
if(empty($rand)){
    $rand = array_rand($read,1);
}else{
    $rand = $rand-1;
    if($rand < 0 || $rand >= count($read)){
        $rand = 0;
    }
}
$name = $read[$rand]['file'];
$file = teacher_curl($url);
if(empty($file)){
    Switch($Type){
        case 'text':
        send('获取失败请重试','text');
        break;
        default:
        header('content-type:image/jpeg');
        $image = new imagick('./tumeile.jpg');
        echo $image;
        exit();
        break;
    }
}
file_put_Contents(md5($url),$file);
$image = new imagick(md5($url));//建立头像
$format = $image->getImageFormat();//获取图片格式
if($format != 'GIF'){
//不是动图处理
    $image->setimageformat('png');//改变图像格式为png
    $size = $image->getimagegeometry();//获取宽高数据
    $width = $size['width'];//宽度
    $height = $size['height'];//高度
    $imagick = new imagick($name);//建立头像框
    $imagick->resizeImage($width,$height,Imagick::FILTER_LANCZOS,1);//修改头像框大小与头像一样
    $image->compositeImage($imagick,Imagick::COMPOSITE_ATOP,0,0);//头像与头像框合并
    header('Content-Type:image/png');
    echo $image->getImageBlob();//输出合并的图;COMPOSITE_COPYOPACITY
}else{
    //动图处理
    $delay = $_REQUEST['delay']?:5;//获取播放速度
    if(!is_numeric($delay) || $delay > 30){
        $delay = 5;//默认值
    }
    $image->setimageformat('GIF');//设置图像格式
    $format = $image->coalesceImages();//获取每一帧
    $GIF = new imagick();//创建图像
    $GIF->setFormat('gif');//设置图像格式
    foreach($format as $k=>$v){
        file_put_contents('./gif/'.md5($url.$k).'.gif',$v);//把每一帧保存起来
    }
    for($i = 0 ; $i < count($format) ; $i++){
        $img = new imagick();//初始化imagick
        $img->readImage('./gif/'.md5($url.$i).'.gif');//以本地方式创建
    //    $img->modulateImage(100,0,100);//设置为黑白色
        $img->setformat('gif');//设置为gif
        $size = $img->getimagegeometry();//获取宽
        $width = $size['width'];//宽度
        $height = $size['height'];//高度
        $imagick = new imagick($name);//初始化边框图
        $imagick->setimageformat('GIF');//设置边框图格式
        $imagick->resizeImage($width,$height,Imagick::FILTER_LANCZOS,1);//调整边框图片大小
        $img->compositeImage($imagick,Imagick::COMPOSITE_COPYOPACITY,0,0);//合并边框与头像图
        $GIF->addImage($img);//添加到GIF图片上
        $GIF->setImageDelay($delay);//设置播放速度
    }
    header('content-type:image/GIF');
     $GIF->writeImages(md5($url).'.gif',true);
     $image = file_get_contents('./'.md5($url).'.gif');
     echo $image;
}
fastcgi_finish_request();//先返回上面的内容
time_sleep_until(time()+10);//延迟10秒后执行下面的命令
unlink(md5($url).'.png');
unlink(md5($url).'.gif');
unlink(md5($url));
for($i = 0 ; $i < count($format) ; $i++){
    unlink('./gif/'.md5($url.$i).'.gif');
}
function read_all($dir){
    if (!is_dir($dir)) {
        return array();
    }
    $handle = opendir($dir);
    if ($handle) {
        while (($fl = readdir($handle)) !== false) {
            $temp = iconv('utf-8', 'utf-8', $dir . DIRECTORY_SEPARATOR . $fl);
            //转换成utf-8格式
            //如果不加  $fl!='.' && $fl != '..'  则会造成把$dir的父级目录也读取出来
            if (!(is_dir($temp) && $fl != '.' && $fl != '..')) {
                if ($fl != '.' && $fl != '..') {
                    $suffix = substr(strrchr($fl, '.'), 1);
                    if ($suffix == "png" || $suffix == 'jpg') {
                        $textarray[] = array("path" => $dir . DIRECTORY_SEPARATOR, "name" => $fl,'file'=>$dir.'/'.$fl);
                    }
                }
            }
        }
    }
    return $textarray;
}
